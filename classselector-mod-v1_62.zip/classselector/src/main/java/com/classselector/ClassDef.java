package com.classselector;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.List;

public class ClassDef {
    public String id = "";
    public String name = "";
    public String description = "";
    public String icon = "minecraft:iron_sword";
    public List<String> abilities = new ArrayList<>();
    public List<ItemStack> items = new ArrayList<>();

    public static String sanitize(String raw) {
        String s = raw.toLowerCase().trim().replaceAll("[^a-z0-9_]", "_");
        return s.length() > 32 ? s.substring(0, 32) : s;
    }

    public ItemStack iconStack() {
        ResourceLocation rl = ResourceLocation.tryParse(icon);
        Item it = rl == null ? null : ForgeRegistries.ITEMS.getValue(rl);
        return new ItemStack(it == null || it == Items.AIR ? Items.BARRIER : it);
    }

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putString("id", id);
        t.putString("name", name);
        t.putString("description", description);
        t.putString("icon", icon);
        ListTag ab = new ListTag();
        for (String s : abilities) ab.add(StringTag.valueOf(s));
        t.put("abilities", ab);
        ListTag its = new ListTag();
        for (ItemStack s : items) its.add(s.save(new CompoundTag()));
        t.put("items", its);
        return t;
    }

    public static ClassDef load(CompoundTag t) {
        ClassDef d = new ClassDef();
        d.id = t.getString("id");
        d.name = t.getString("name");
        d.description = t.getString("description");
        d.icon = t.getString("icon");
        for (Tag x : t.getList("abilities", Tag.TAG_STRING)) d.abilities.add(x.getAsString());
        for (Tag x : t.getList("items", Tag.TAG_COMPOUND)) {
            ItemStack s = ItemStack.of((CompoundTag) x);
            if (!s.isEmpty()) d.items.add(s);
        }
        return d;
    }
}
