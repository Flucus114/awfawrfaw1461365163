package com.classselector;

import net.minecraft.client.model.WardenModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.monster.warden.Warden;

/** Modelo do Warden que, quando o Warden domado está sentado, assume a pose sentada. */
public class SitWardenModel extends WardenModel<Warden> {
    private final ModelPart bone, body, head, rightArm, leftArm, rightLeg, leftLeg;

    public SitWardenModel(ModelPart root) {
        super(root);
        this.bone = root.getChild("bone");
        this.body = bone.getChild("body");
        this.head = body.getChild("head");
        this.rightArm = body.getChild("right_arm");
        this.leftArm = body.getChild("left_arm");
        this.rightLeg = bone.getChild("right_leg");
        this.leftLeg = bone.getChild("left_leg");
    }

    @Override
    public void setupAnim(Warden w, float limbSwing, float limbSwingAmount, float age, float netHeadYaw, float headPitch) {
        super.setupAnim(w, limbSwing, limbSwingAmount, age, netHeadYaw, headPitch);
        if (!TamedWarden.isSitting(w)) return;

        float breathe = Mth.sin(age * 0.08F);

        // desce o corpo até o chão
        bone.y += 9.0F;

        // pernas esticadas para frente, abertas
        rightLeg.xRot = -1.45F;
        rightLeg.yRot = 0.30F;
        rightLeg.zRot = 0.0F;
        leftLeg.xRot = -1.45F;
        leftLeg.yRot = -0.30F;
        leftLeg.zRot = 0.0F;

        // tronco levemente curvado para frente, respirando
        body.xRot += 0.10F + breathe * 0.02F;

        // braços e cabeça só são posados se ele não estiver atacando/rugindo
        boolean busy = w.attackAnimationState.isStarted()
                || w.sonicBoomAnimationState.isStarted()
                || w.roarAnimationState.isStarted();
        if (!busy) {
            rightArm.xRot = -0.45F + breathe * 0.02F;
            rightArm.yRot = 0.0F;
            rightArm.zRot = 0.12F;
            leftArm.xRot = -0.45F + breathe * 0.02F;
            leftArm.yRot = 0.0F;
            leftArm.zRot = -0.12F;
            head.zRot = 0.22F + breathe * 0.03F;
        }
    }
}
