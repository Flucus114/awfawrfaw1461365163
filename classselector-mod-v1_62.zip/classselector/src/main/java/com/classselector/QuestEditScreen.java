package com.classselector;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.List;

/** Editor de quest (só OP): objetivo, progressão e recompensa. */
public class QuestEditScreen extends Screen {
    private final Screen parent;
    private final String tabId;
    private final QuestDef orig;

    private EditBox id, name, desc, icon, target, amount, xp;
    private Button typeBtn, parentBtn;
    private QuestType type;
    private final List<String> parents = new ArrayList<>();
    private int parentIdx = 0;

    private String classId;
    private Button classBtn;

    private String className(String cid) {
        if (cid.isEmpty()) return "Todas as classes";
        for (ClassDef c : ClientState.classes) if (c.id.equals(cid)) return c.name;
        return cid + " (apagada)";
    }

    private void cycleClass() {
        List<String> opts = new ArrayList<>();
        opts.add("");
        for (ClassDef c : ClientState.classes) opts.add(c.id);
        int i = opts.indexOf(classId);
        classId = opts.get((i + 1) % opts.size());
        classBtn.setMessage(Component.literal("Só a classe: " + className(classId)));
    }

    public QuestEditScreen(Screen parent, String tabId, QuestDef orig) {
        super(Component.literal(orig == null ? "Nova quest" : "Editar quest"));
        this.parent = parent;
        this.tabId = tabId;
        this.orig = orig;
        this.classId = orig == null ? "" : orig.classId;
        this.type = orig == null ? QuestType.BLOCK : orig.type;
        parents.add("");
        for (QuestDef q : QuestClientState.quests.values()) {
            if (q.tab.equals(tabId) && (orig == null || !q.id.equals(orig.id))) parents.add(q.id);
        }
        if (orig != null && parents.contains(orig.parent)) parentIdx = parents.indexOf(orig.parent);
    }

    private EditBox box(int x, int y, int w, int maxLen, String val) {
        EditBox b = new EditBox(font, x, y, w, 18, Component.empty());
        b.setMaxLength(maxLen);
        b.setValue(val);
        addRenderableWidget(b);
        return b;
    }

    private EditBox num(int x, int y, int val) {
        EditBox b = box(x, y, 150, 8, String.valueOf(val));
        b.setFilter(s -> s.isEmpty() || s.matches("\\d*"));
        return b;
    }

    private static int parseInt(EditBox b, int def) {
        try { return Integer.parseInt(b.getValue().trim()); } catch (Exception e) { return def; }
    }

    private int y0() { return Math.max(16, height / 2 - 110); }

    private String parentLabel() {
        String pid = parents.get(parentIdx);
        if (pid.isEmpty()) return "Nenhum (início)";
        QuestDef q = QuestClientState.quests.get(pid);
        return q == null ? pid : q.name;
    }

    private void refreshButtons() {
        typeBtn.setMessage(Component.literal(type.label));
        parentBtn.setMessage(Component.literal(parentLabel()));
        target.setEditable(type.needsTarget());
        target.setVisible(true);
    }

    @Override
    protected void init() {
        int cx = width / 2, lx = cx - 155, rx = cx + 5, y = y0(), s = 32;

        id = box(lx, y + 11, 150, 64, orig == null ? "" : orig.id);
        id.setEditable(orig == null);
        name = box(lx, y + 11 + s, 150, 64, orig == null ? "" : orig.name);
        desc = box(lx, y + 11 + 2 * s, 150, 256, orig == null ? "" : orig.description);
        icon = box(lx, y + 11 + 3 * s, 150, 256, orig == null ? "minecraft:book" : orig.icon);
        addRenderableWidget(Button.builder(Component.literal("Ícone = item na mão"), b -> {
            ItemStack held = minecraft.player.getMainHandItem();
            if (!held.isEmpty()) icon.setValue(ForgeRegistries.ITEMS.getKey(held.getItem()).toString());
        }).bounds(lx, y + 11 + 4 * s, 150, 20).build());

        typeBtn = addRenderableWidget(Button.builder(Component.empty(), b -> {
            type = type.next();
            refreshButtons();
        }).bounds(rx, y + 10, 150, 20).build());
        target = box(rx, y + 11 + s, 100, 256, orig == null ? "minecraft:oak_log" : orig.target);
        addRenderableWidget(Button.builder(Component.literal("Mão"), b -> {
            ItemStack held = minecraft.player.getMainHandItem();
            if (!held.isEmpty()) target.setValue(ForgeRegistries.ITEMS.getKey(held.getItem()).toString());
        }).bounds(rx + 104, y + 10 + s, 46, 20).build());
        amount = num(rx, y + 11 + 2 * s, orig == null ? 1 : orig.amount);
        xp = num(rx, y + 11 + 3 * s, orig == null ? 0 : orig.xp);
        parentBtn = addRenderableWidget(Button.builder(Component.empty(), b -> {
            parentIdx = (parentIdx + 1) % parents.size();
            refreshButtons();
        }).bounds(rx, y + 10 + 4 * s, 150, 20).build());
        refreshButtons();

        classBtn = addRenderableWidget(Button.builder(
                Component.literal("Só a classe: " + className(classId)), b -> cycleClass())
                .bounds(lx, y + 11 + 4 * s + 24, 310, 20).build());

        int by = y + 11 + 4 * s + 50;
        addRenderableWidget(Button.builder(Component.literal("Salvar"), b -> { if (save()) onClose(); })
                .bounds(lx, by, 74, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Recompensa"), b -> {
            if (save()) Net.CH.sendToServer(new QuestNet.QEditRewards(ClassDef.sanitize(id.getValue())));
        }).bounds(lx + 79, by, 74, 20).build());
        Button del = addRenderableWidget(Button.builder(Component.literal("Excluir"), b -> {
            Net.CH.sendToServer(new QuestNet.QDeleteQuest(orig.id));
            onClose();
        }).bounds(lx + 158, by, 74, 20).build());
        del.active = orig != null;
        addRenderableWidget(Button.builder(Component.literal("Voltar"), b -> onClose())
                .bounds(lx + 237, by, 73, 20).build());
    }

    private boolean save() {
        String qid = ClassDef.sanitize(id.getValue());
        if (qid.isEmpty() || name.getValue().isBlank()) return false;
        QuestDef q = new QuestDef();
        q.id = qid;
        q.tab = tabId;
        q.parent = parents.get(parentIdx);
        q.name = name.getValue().trim();
        q.description = desc.getValue().trim();
        q.icon = icon.getValue().trim();
        q.type = type;
        q.target = type.needsTarget() ? target.getValue().trim() : "";
        q.amount = Math.max(1, parseInt(amount, 1));
        q.xp = Math.max(0, parseInt(xp, 0));
        q.classId = classId;
        if (orig != null) q.rewards = orig.rewards;
        Net.CH.sendToServer(new QuestNet.QSaveQuest(q.save()));
        return true;
    }

    @Override
    public void onClose() { minecraft.setScreen(parent); }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        int cx = width / 2, lx = cx - 155, rx = cx + 5, y = y0(), s = 32, c = 0xFFAAAAAA;
        g.drawCenteredString(font, title, cx, Math.max(2, y - 12), 0xFFFFFF);
        g.drawString(font, "ID (a-z, 0-9, _)", lx, y, c, false);
        g.drawString(font, "Nome", lx, y + s, c, false);
        g.drawString(font, "Descrição", lx, y + 2 * s, c, false);
        g.drawString(font, "Ícone (id do item)", lx, y + 3 * s, c, false);
        g.drawString(font, "Tipo de objetivo (clique p/ trocar)", rx, y, c, false);
        g.drawString(font, type == QuestType.BOSS ? "Alvo (id da entidade)"
                : type == QuestType.ITEM ? "Alvo (id do item)"
                : type == QuestType.BLOCK ? "Alvo (id do bloco)" : "Alvo (não usado)", rx, y + s, c, false);
        g.drawString(font, "Quantidade", rx, y + 2 * s, c, false);
        g.drawString(font, "Recompensa: níveis de XP", rx, y + 3 * s, c, false);
        g.drawString(font, "Pré-requisito (clique p/ trocar)", rx, y + 4 * s, c, false);
        super.render(g, mx, my, pt);
    }
}
